from odoo import models, fields, api

class IspOltCard(models.Model):
    _name = 'isp.olt.card'
    _description = 'Tarjeta de Equipo OLT'
    _inherit = [ 'mail.thread', 'mail.activity.mixin']


    olt_id = fields.Many2one('isp.olt', string='OLT', required=True)

    name = fields.Char(string='Nombre')

    # --- Campos de Acceso y Configuración ---
    num_card = fields.Integer(string='Número Slot')
    poolip = fields.Char(string='Poolip')
    dhcp_custom_server = fields.Char(string='DHCP Leases')

    port_card = fields.Selection([
        ('8', '8 Puertos'),
        ('16', '16 Puertos'),
        ('32', '32 Puertos'),
        ('64', '64 Puertos'),
    ], string='Cantidad de Puertos')

    contracts_card_count = fields.Integer(string='Conteo Tarjetas Olt', compute='_compute_counts')

    olt_card_port_count = fields.Integer(string='Conteo Puertos', compute='_compute_counts')
    

    @api.model
    def create(self, vals):
        if vals.get('olt_id'):
            olt = self.env['isp.olt'].browse(vals['olt_id'])
            if olt.exists():
                card_count = self.search_count([('olt_id', '=', olt.id)])
                vals['name'] = f"{olt.name}/C{card_count + 1}"
        return super(IspOltCard, self).create(vals)

    def write(self, vals):
        # If the olt_id is being changed, we need to rename the card
        if 'olt_id' in vals:
            new_olt = self.env['isp.olt'].browse(vals['olt_id'])
            if new_olt.exists():
                for record in self:
                    # We need to count the cards in the new OLT to get the next number
                    card_count = self.search_count([('olt_id', '=', new_olt.id)])
                    record.name = f"{new_olt.name}/C{card_count + 1}"
        return super(IspOltCard, self).write(vals)

    def _compute_olt_card_port_count(self):
        for record in self:
            record.olt_card_port_count = self.env['isp.olt.card.port'].search_count([('olt_card_id', '=', record.id)])

    def _compute_contracts_card_count(self):
        for record in self:
            record.contracts_card_count = self.env['isp.contract'].search_count([('olt_card_id', '=', record.id)])

    def create_olt_card_port(self):
        self.ensure_one()
        ports_to_create = []
        for i in range(int(self.port_card)):
            ports_to_create.append({
                'name': f"{self.name}/port/{i+1}",
                'olt_card_id': self.id,
            })
        self.env['isp.olt.card.port'].create(ports_to_create)
        return {
            'name': 'Puertos de Tarjeta OLT',
            'type': 'ir.actions.act_window',
            'res_model': 'isp.olt.card.port',
            'view_mode': 'tree,form',
            'domain': [('olt_card_id', '=', self.id)],
            'target': 'current',
        }

    def action_view_olt_card_ports(self):
        self.ensure_one()
        return {
            'name': 'Puertos OLT',
            'type': 'ir.actions.act_window',
            'res_model': 'isp.olt.card.port',
            'view_mode': 'tree,form',
            'domain': [('olt_card_id', '=', self.id)],
            'context': {'default_olt_card_id': self.id},
            'target': 'current',
        }

    def action_view_contracts(self):
        self.ensure_one()
        return {
            'name': 'Contratos',
            'type': 'ir.actions.act_window',
            'res_model': 'isp.contract',
            'view_mode': 'tree,form',
            'domain': [('olt_card_id', '=', self.id)],
            'context': {'default_olt_card_id': self.id},
            'target': 'current',
        }
